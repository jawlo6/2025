<?php
      //liczby calkowite
      $liczba = 1234; //dziesiętna
      $oktalna = 0123; //ósemkowa
      $hex = 0x1A; //szesnastkowa   
      $binary = 0b10101010; //binarna
      $big = 1_123_567; //duże liczby
      echo $liczba . "<br>";
      print $oktalna . "<br>";
      echo $hex . "<br>" . $binary . "<br>";
      echo $big;
      

?>