<form action="register.php" method="post">
    Login: <input type="text" name="name"><br>
    Password: <input type="password" name="haslo"><br>
    <input type="submit">
    </form>