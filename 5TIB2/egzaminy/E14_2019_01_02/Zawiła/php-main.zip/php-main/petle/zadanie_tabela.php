<?php
echo "<table style='border: 1px solid red'>";
echo "<tr><th>Element</th></tr>";
for ($i = 1; $i <= 5; $i++) {
    echo "<tr><td>Element $i</td></tr>";
}
echo "</table>";
?>
