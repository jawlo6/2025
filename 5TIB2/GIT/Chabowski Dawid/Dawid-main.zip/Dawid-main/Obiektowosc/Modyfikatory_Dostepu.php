<?php
    class Fruit {
        public $name;
        protected $color;
        private $weight;
}
    $mango = new Fruit();
    $mango->name = 'Mango';          
    $mango->color = 'Yellow';        
    $mango->weight = 300;            
    echo $mango->name;
?>