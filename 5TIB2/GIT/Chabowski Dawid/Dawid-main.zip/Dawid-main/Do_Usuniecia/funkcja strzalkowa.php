<?php 
$y = 1;
$fn1 = fn($x) => $x + $y;
echo $fn1(3);
?>