<?php
$x = 0;

do {
    echo "Wartość x to: $x<br>";
    $x -= 2;
} while ($x >= -10);
?>
