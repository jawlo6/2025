<?php
$age = array("Jan" => 25, "Anna" => 30, "Piotr" => 35);

foreach ($age as $name => $age_value) {
    echo "$name ma $age_value lat.<br>";
}