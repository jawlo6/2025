<?php
    $cars = array("Volvo", "BMW", "Toyota");

    sort($cars);    
                   
?>