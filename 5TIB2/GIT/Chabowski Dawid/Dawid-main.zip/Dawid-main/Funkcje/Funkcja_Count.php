<?php
    $cars = array("Volvo", "BMW", "Toyota");
    echo "Size of array cars = " . count($cars);
?>