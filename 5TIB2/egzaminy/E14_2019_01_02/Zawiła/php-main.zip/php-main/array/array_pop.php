<?php
    $a = array("red", "green", "blue");
    array_pop($a);    // removes the last element of the array
                        // output: ["red", "green"]
    print_r($a); // output Array ( [0] => red [1] => green )
?>