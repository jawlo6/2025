<?php
    echo strpos("Hello world!", "world");
?>