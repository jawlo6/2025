<?php
for ($i = 0; $i < 10; $i++) {
    echo "Wartość i to: $i<br>";
}
    if ($i == 5) {
        break; // Przerwanie pętli, gdy i osiągnie wartość 5
    }
echo "Pętla zakończona.";
?>