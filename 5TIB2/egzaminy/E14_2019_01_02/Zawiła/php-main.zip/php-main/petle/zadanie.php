<?php
echo "<ul>";
for ($i = 1; $i <= 5; $i++) {
    echo "<li>Element $i</li>";
}
echo "</ul>";
?>
