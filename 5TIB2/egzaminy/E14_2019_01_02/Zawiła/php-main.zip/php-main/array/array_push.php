<?php
    $a = array("red", "green");
    array_push($a, "blue", "yellow"); // adds one or more elements to the end of the array
                                     // output: ["red", "green", "blue", "yellow"]
    print_r($a); // output Array ( [0] => red [1] => green [2] => blue [3] => yellow )
?>