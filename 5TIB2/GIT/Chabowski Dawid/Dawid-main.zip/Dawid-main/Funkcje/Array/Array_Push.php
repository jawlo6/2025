<?php
    $a = array("red", "green");
    array_push($a, "blue", "yellow");
    print_r($a);
?>