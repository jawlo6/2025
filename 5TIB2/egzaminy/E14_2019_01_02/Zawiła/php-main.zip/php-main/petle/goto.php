<?php

goto a;
echo "Pierwszy tekst";

a: //tzw. etykieta
echo "Drugi tekst";

?>