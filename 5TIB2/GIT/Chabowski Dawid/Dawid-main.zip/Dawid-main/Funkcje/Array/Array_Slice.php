<?php
    $a = array("red", "green", "blue", "yellow", "brown");
    print_r(array_slice($a, 2));
?>


<?php
    $a = array("red", "green", "blue", "yellow", "brown");
    print_r(array_slice($a, -2,1));
?>