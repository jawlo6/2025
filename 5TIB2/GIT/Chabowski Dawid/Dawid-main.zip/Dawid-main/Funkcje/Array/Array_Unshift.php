<?php
    $a = array("a"=>"red", "b"=>"green");
    array_unshift($a, "blue");
    print_r($a);
?>