<?php
    //stringi - heredoc - od PHP 7.3
    echo <<<END
          a
         b
        c
\n
END;

// 4 spaces of indentation
echo <<<END
      a
     b
    c
    END;
?>
