<?php
$fliename = 'ddd.txt'; 
echo $fliename . " : " . filesize($fliename) . " bajtów.";
?>