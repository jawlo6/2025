<?php
$a_bool = TRUE;
$name = 'Karol';
$an_int = 12;
$pi = 3.31415926;
echo gettype($a_bool) . "<br>";
echo is_float($pi) . "<br>";
print var_dump($name) . "<br>";

?>