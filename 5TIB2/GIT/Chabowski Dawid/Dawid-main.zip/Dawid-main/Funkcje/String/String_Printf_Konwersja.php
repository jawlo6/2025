<?php
    $n=43951789;
    printf("%%d = '%d'\n", $n);
    printf("%%f = '%f'\n", $n);
    printf("%%e = '%e'\n", $n);
    printf("%%b = '%b'\n", $n);
    printf("%%o = '%o'\n", $n);
    printf("%%s = '%s'\n", $n);
    printf("%%x = '%x'\n", $n);
?>