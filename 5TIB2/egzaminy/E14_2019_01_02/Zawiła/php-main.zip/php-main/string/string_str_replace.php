<?php
    echo str_replace("world", "everyone", "Hello world!"); // outputs Hello everyone!
?>