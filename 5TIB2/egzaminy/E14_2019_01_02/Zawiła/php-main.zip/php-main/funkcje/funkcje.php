<?php
function writeMessage() {
    echo "Witaj w funkcji!<br>";
}

writeMsg(); // Wywołanie funkcji
?>