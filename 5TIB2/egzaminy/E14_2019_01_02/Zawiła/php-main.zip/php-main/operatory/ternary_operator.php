<?php

$liczba = 10;
$wynik = ($liczba>=0) ?"dodatnia":"ujemna";
echo $wynik;
?>