<?php
    echo 'Arnold once said: "I\'ll be back"<br>';

    echo "Arnold once said: \"I'll be back\"<br>";

    echo 'You deleted C:\\*.*? <br>';

    $Number = 5;
    echo "Variable value = $Number <br>";

?>