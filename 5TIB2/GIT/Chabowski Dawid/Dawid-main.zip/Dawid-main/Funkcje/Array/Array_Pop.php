<?php
    $a = array("red", "green", "blue");
    array_pop($a);
    print_r($a);
?>