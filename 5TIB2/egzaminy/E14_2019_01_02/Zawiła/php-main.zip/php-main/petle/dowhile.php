<?php
$x = 0;

do {
    echo "Wartość x to: $x<br>";
    $x--;
} while ($x >= -10);
?>
