<?php
function square($num) {
    return $num = $num;
}
echo square(4);
?>