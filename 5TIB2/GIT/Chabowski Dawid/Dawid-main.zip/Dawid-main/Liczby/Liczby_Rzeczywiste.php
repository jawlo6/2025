<?php
    $a = 1.234;
    $b = 1.2e3;
    $c = 7E-10;
    $d = 1_234.567;

    print("Liczba a to: " . $a);
    print("<br>Liczba b to: " . $b);
    print("<br>Liczba c to: " . $c);
    print("<br>Liczba d to: " . $d);
?>