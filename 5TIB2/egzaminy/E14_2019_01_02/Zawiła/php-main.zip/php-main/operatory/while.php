<?php
$x = 1;
while($x <= 5) {
    echo "The number is: $x <br>";
    $x++;
}

$x = 0;
while($x = >-5) {
    echo "The number is: $x <br>";
    $x--;
}
?>