<?php
    $hour = date("H");

    if ($hour < 20) {
        echo "Have a good day!";
    } else {
        echo "Have a good night!";
    }
?>