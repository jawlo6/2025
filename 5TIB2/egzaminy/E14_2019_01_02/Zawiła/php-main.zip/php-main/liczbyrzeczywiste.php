<?php
$a = 1.234;
print "liczba a = $a<br>";
$b = 1.2e3;
print "liczba b = $b<br>";
$c = 7E-10;     
print "liczba c = $c<br>";
$d = 1_234.567;
print "liczba d = $d<br>";
?>