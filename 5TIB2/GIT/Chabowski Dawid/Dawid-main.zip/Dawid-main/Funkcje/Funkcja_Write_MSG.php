<?php
    function writeMSG(){ 
        echo "czesc";
    }
    writeMSG()
?>