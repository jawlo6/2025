<?php
    $tekst = "Hello";
    printf("[%s]\n", $tekst);
    printf("[%10s]\n", $tekst);
    printf("[%-10s]\n", $tekst);
    printf("[%.3s]\n", $tekst);
    printf("[%10.3s]\n", $tekst);
    printf("[%-10.3s]\n", $tekst);
?>