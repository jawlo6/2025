<?php
    $imiona = array("Jan", "Anna", "Tomasz", "Zofia");
    echo implode(" ", $imiona); // output Jan Anna Tomasz Zofia
?>