<?php
$Liczba1 =42;
print ("Liczba to: " . $Liczba1 . "<br>");
$LiczbaOctalna = 042;
print ("Liczba ósemkowa to: " . $LiczbaOctalna . "<br>");
$LiczbaHex = 0x2A;
print ("Liczba szesnastkowa to: " . $LiczbaHex . "<br>");
$LiczbaBinarna = 0b101010;  
print ("Liczba binarna to: " . $LiczbaBinarna . "<br>");
$LiczbaDuza = 1_234_567;
print ("Duża liczba to: " . $LiczbaDuza . "<br>");
?>