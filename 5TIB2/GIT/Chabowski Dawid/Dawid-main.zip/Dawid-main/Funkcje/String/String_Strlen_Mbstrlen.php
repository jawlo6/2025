<?php
    echo strlen("Hello world!");
    echo strlen("Łódź");
    echo mb_strlen("Łódź");
?>