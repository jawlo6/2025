<?php
    $x=0;
    do {
        echo "Liczba to: $x <br>";
        $x--;
    } while($x>=-10);
?>