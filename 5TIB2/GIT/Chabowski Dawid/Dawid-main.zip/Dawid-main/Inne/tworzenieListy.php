<?php
    echo "<ul>";
    for ($i=0; $i <=10; $i++)
        {echo "<li>$i</li>";
        }
            echo "</ul>"; 
?>