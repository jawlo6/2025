<?php
    $cars = array("Volvo", "BMW", "Toyota");

    rsort($cars);   
                   
?>