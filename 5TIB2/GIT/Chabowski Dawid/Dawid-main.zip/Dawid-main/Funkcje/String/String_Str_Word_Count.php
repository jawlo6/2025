<?php
    echo str_word_count("Hello world!");
?>