<?php
    $a = 2;
    $b = 1;
    if ($a > $b) {
        echo "a is bigger than b";
    }
?>