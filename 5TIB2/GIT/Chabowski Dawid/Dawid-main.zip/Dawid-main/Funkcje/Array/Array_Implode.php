<?php
    $imiona = array("Jan", "Anna", "Tomasz", "Zofia");
    echo implode(" ", $imiona);
?>