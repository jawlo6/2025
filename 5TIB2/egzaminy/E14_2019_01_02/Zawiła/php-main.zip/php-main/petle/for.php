<?php
for ($x = 0; $x <= 5; $x++) {
    echo "Wartość x to: $x<br>";
}

?>