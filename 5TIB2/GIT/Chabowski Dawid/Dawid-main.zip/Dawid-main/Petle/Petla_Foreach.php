<?php
    $age=array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
    foreach($age as $key=>$val){
        echo "$key=$val<br>";
    }
?>