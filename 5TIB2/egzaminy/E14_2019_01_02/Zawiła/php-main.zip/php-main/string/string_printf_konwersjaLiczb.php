<?php
    $n=43951789;
    printf("%%d = '%d'\n", $n); // standard integer representation
    printf("%%f = '%f'\n", $n); // floating point representation
    printf("%%e = '%e'\n", $n); // scientific notation
    printf("%%b = '%b'\n", $n); // binary representation
    printf("%%o = '%o'\n", $n); // octal representation
    printf("%%s = '%s'\n", $n); // string representation
    printf("%%x = '%x'\n", $n); // hexadecimal representation (lower-case)
?>