<?php
$colors = array("czerwony", "zielony", "niebieski");

foreach ($colors as $color) {
    echo "Kolor: $color<br>";
}