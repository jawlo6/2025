<?php
    echo 'Arnold once said: "I\'ll be back"<br>'; //Arnold once said: "I'll be back"

    //Zapis NR2
    echo "Arnold once said: \"I'll be back\"<br>"; //Arnold once said: "I'll be back"

    echo 'You deleted C:\\*.*? <br>'; //You deleted C:\*.*


    //zmienne w stringach
    $Number = 5;
    echo "Variable value = $Number <br>"; //Variable value = 5

?>