<?php
$filename = 'somefile.txt';
echo $filename . ': ' . filesize($filename) . ' bytes';
?>