<?php
    $rok = date("Y");
    $miesiac = date("m");
    $dzien = date("d");
    echo "$dzien/$miesiac/$rok <br>";

    echo "Today is " . date("Y/m/d") . "<br>";
    echo "Today is " . date("l") . "<br>";
?>