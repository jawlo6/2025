<?php
setcookie("uczen", "Lukasz", time() + (25 * 24 * 3600), "/");
echo "Cookie zostało utworzone.";
?>
