<?php
    $liczba = 1234; 
    $oktalna = 0123; 
    $hex = 0x1A; 
    $binary = 0b10101010;
    $big = 1_123_567;

    echo $liczba."<br>";
    print $oktalna."<br>";
    echo $hex."<br>" . $binary."<br>";
    echo $big;
?>