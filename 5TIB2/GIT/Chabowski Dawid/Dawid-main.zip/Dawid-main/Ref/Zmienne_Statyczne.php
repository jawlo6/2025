    <?php
        function test() {
            static $licznik = 0;
            echo $licznik . "<br>";
            $licznik++;
        }
        test();
        test();
        test();
    ?>