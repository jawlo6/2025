<?php
$favcolor = "red";

switch ($favcolor) {
    case "red":
        echo "Your favorite color is red!";
        break;
    case "blue":
        echo "Your favorite color is blue!";
        break;

        default:
        echo "Your favorite color is neither red, blue, nor green!";
    }
?>
