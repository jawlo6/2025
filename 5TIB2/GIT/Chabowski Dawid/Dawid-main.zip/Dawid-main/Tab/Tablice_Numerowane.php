<?php
$cars = array("Volvo", "BMW", "Toyota");

$cars = ["Volvo", "BMW", "Toyota"];

$cars = [];
$cars[0] = "Volvo";
$cars[1] = "BMW";
$cars[2] = "Toyota";
?>