<?php
    echo <<<'EOD' 
    Exaple of string spanning multiple lines 
    using nowdoc syntax. Backslashes are always treated literally, 
    e.g. \\ and \'. 
    EOD; 
?>