<?php
    echo "<table style='border: 1px solid red'>";
    echo "<tr><th>0</th></tr>";
    for ($i = 1; $i <= 5; $i++) {
        echo "<tr><td>$i</td></tr>"; 
    }
    echo "</table>"; 
?>